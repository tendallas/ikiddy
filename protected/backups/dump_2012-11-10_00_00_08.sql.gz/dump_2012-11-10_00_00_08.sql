
--
-- Structure for table `ActionLog`
--

DROP TABLE IF EXISTS `ActionLog`;
CREATE TABLE `ActionLog` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) NOT NULL,
  `event` tinyint(255) NOT NULL,
  `model_name` varchar(50) NOT NULL,
  `model_title` text NOT NULL,
  `datetime` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `username` (`username`),
  KEY `event` (`event`),
  KEY `datetime` (`datetime`),
  KEY `model_name` (`model_name`)
) ENGINE=MyISAM AUTO_INCREMENT=171 DEFAULT CHARSET=utf8;


--
-- Data for table `ActionLog`
--

INSERT INTO `ActionLog` (`id`, `username`, `event`, `model_name`, `model_title`, `datetime`) VALUES
 ('1', 'ten', '2', 'StoreCurrency', 'Гривна', '2012-11-03 18:07:11'),
 ('2', 'ten', '2', 'StoreCategory', 'root', '2012-11-03 23:11:20'),
 ('3', 'ten', '1', 'StoreCategory', 'Одежда для мальчиков', '2012-11-03 23:12:05'),
 ('4', 'ten', '1', 'StoreCategory', 'Одежда для девочек', '2012-11-03 23:12:15'),
 ('5', 'ten', '3', 'StoreManufacturer', 'Lenovo', '2012-11-03 23:24:14'),
 ('6', 'ten', '3', 'StoreManufacturer', 'Asus', '2012-11-03 23:24:14'),
 ('7', 'ten', '3', 'StoreManufacturer', 'Dell', '2012-11-03 23:24:14'),
 ('8', 'ten', '3', 'StoreManufacturer', 'Fujitsu', '2012-11-03 23:24:14'),
 ('9', 'ten', '3', 'StoreManufacturer', 'HP', '2012-11-03 23:24:14'),
 ('10', 'ten', '3', 'StoreManufacturer', 'Apple', '2012-11-03 23:24:14'),
 ('11', 'ten', '3', 'StoreManufacturer', 'Sony', '2012-11-03 23:24:14'),
 ('12', 'ten', '3', 'StoreManufacturer', 'Acer', '2012-11-03 23:24:14'),
 ('13', 'ten', '3', 'StoreManufacturer', 'Logitech', '2012-11-03 23:24:14'),
 ('14', 'ten', '3', 'StoreManufacturer', 'Microlab', '2012-11-03 23:24:14'),
 ('15', 'ten', '3', 'StoreManufacturer', 'Edifier', '2012-11-03 23:24:14'),
 ('16', 'ten', '3', 'StoreManufacturer', 'Sven', '2012-11-03 23:24:14'),
 ('17', 'ten', '3', 'StoreManufacturer', 'LG', '2012-11-03 23:24:14'),
 ('18', 'ten', '3', 'StoreManufacturer', 'Samsung', '2012-11-03 23:24:14'),
 ('19', 'ten', '3', 'StoreManufacturer', 'Philips', '2012-11-03 23:24:14'),
 ('20', 'ten', '3', 'StoreManufacturer', 'HTC', '2012-11-03 23:24:14'),
 ('21', 'ten', '3', 'StoreManufacturer', 'Nokia', '2012-11-03 23:24:14'),
 ('22', 'ten', '3', 'StoreManufacturer', 'BlackBerry', '2012-11-03 23:24:14'),
 ('23', 'ten', '3', 'StoreProduct', 'Lenovo B570', '2012-11-03 23:24:23'),
 ('24', 'ten', '3', 'StoreProduct', 'Lenovo G570', '2012-11-03 23:24:23'),
 ('25', 'ten', '3', 'StoreProduct', 'ASUS K53U', '2012-11-03 23:24:23'),
 ('26', 'ten', '3', 'StoreProduct', 'ASUS X54C', '2012-11-03 23:24:23'),
 ('27', 'ten', '3', 'StoreProduct', 'DELL INSPIRON N5050', '2012-11-03 23:24:23'),
 ('28', 'ten', '3', 'StoreProduct', 'Microlab FC 362', '2012-11-03 23:24:23'),
 ('29', 'ten', '3', 'StoreProduct', 'DELL U2412M', '2012-11-03 23:24:23'),
 ('30', 'ten', '3', 'StoreProduct', 'DELL U2312HM', '2012-11-03 23:24:23'),
 ('31', 'ten', '3', 'StoreProduct', 'LG Flatron M2250D', '2012-11-03 23:24:24'),
 ('32', 'ten', '3', 'StoreProduct', 'LG Flatron IPS226V', '2012-11-03 23:24:24'),
 ('33', 'ten', '3', 'StoreProduct', 'Samsung SyncMaster S22A350N', '2012-11-03 23:24:24'),
 ('34', 'ten', '3', 'StoreProduct', 'Philips 237E3QPHSU', '2012-11-03 23:24:24'),
 ('35', 'ten', '3', 'StoreProduct', 'Philips 227E3LSU', '2012-11-03 23:24:24'),
 ('36', 'ten', '3', 'StoreProduct', 'HP ZR2740w', '2012-11-03 23:24:24'),
 ('37', 'ten', '3', 'StoreProduct', 'HP ZR2440w', '2012-11-03 23:24:24'),
 ('38', 'ten', '3', 'StoreProduct', 'Samsung Galaxy Ace II', '2012-11-03 23:24:24'),
 ('39', 'ten', '3', 'StoreProduct', 'HTC One XL', '2012-11-03 23:24:24'),
 ('40', 'ten', '3', 'StoreProduct', 'HTC Sensation XL', '2012-11-03 23:24:24'),
 ('41', 'ten', '3', 'StoreProduct', 'Apple iPhone 4S 16Gb', '2012-11-03 23:24:24'),
 ('42', 'ten', '3', 'StoreProduct', 'Apple iPhone 3GS 8Gb', '2012-11-03 23:24:24'),
 ('43', 'ten', '3', 'StoreProduct', 'Apple iPhone 4 16Gb', '2012-11-03 23:24:24'),
 ('44', 'ten', '3', 'StoreProduct', 'Nokia N9', '2012-11-03 23:24:24'),
 ('45', 'ten', '3', 'StoreProduct', 'BlackBerry Bold 9900', '2012-11-03 23:24:24'),
 ('46', 'ten', '3', 'StoreProduct', 'BlackBerry Bold 9780', '2012-11-03 23:24:24'),
 ('47', 'ten', '3', 'StoreProduct', 'Apple iPad 2 16Gb Wi-Fi + 3G', '2012-11-03 23:24:24'),
 ('48', 'ten', '3', 'StoreProduct', 'Apple iPad 2 64Gb Wi-Fi + 3G', '2012-11-03 23:24:24'),
 ('49', 'ten', '3', 'StoreProduct', 'Samsung Galaxy Tab 7.0 Plus P6200 16GB', '2012-11-03 23:24:24'),
 ('50', 'ten', '3', 'StoreProduct', 'Acer Iconia Tab A100 8Gb', '2012-11-03 23:24:24'),
 ('51', 'ten', '3', 'StoreProduct', 'Asus Transformer Pad Prime 201 64Gb', '2012-11-03 23:24:24'),
 ('52', 'ten', '3', 'StoreProduct', 'Samsung Galaxy Tab 10.1 P7500 16Gb', '2012-11-03 23:24:24'),
 ('53', 'ten', '3', 'StoreProduct', 'Fujitsu LIFEBOOK AH531', '2012-11-03 23:24:28'),
 ('54', 'ten', '3', 'StoreProduct', 'HP EliteBook 8560w', '2012-11-03 23:24:28'),
 ('55', 'ten', '3', 'StoreProduct', 'DELL ALIENWARE M17x', '2012-11-03 23:24:28'),
 ('56', 'ten', '3', 'StoreProduct', 'Apple MacBook Pro 15 Late 2011', '2012-11-03 23:24:28'),
 ('57', 'ten', '3', 'StoreProduct', 'Lenovo THINKPAD W520', '2012-11-03 23:24:28'),
 ('58', 'ten', '3', 'StoreProduct', 'Sony VAIO VPC-F13S8R', '2012-11-03 23:24:28'),
 ('59', 'ten', '3', 'StoreProduct', 'Acer ASPIRE 5943G-7748G75TWiss', '2012-11-03 23:24:28'),
 ('60', 'ten', '3', 'StoreProduct', 'Logitech X-530', '2012-11-03 23:24:28'),
 ('61', 'ten', '3', 'StoreProduct', 'Microlab M-860', '2012-11-03 23:24:28'),
 ('62', 'ten', '3', 'StoreProduct', 'Edifier M3700', '2012-11-03 23:24:28'),
 ('63', 'ten', '3', 'StoreProduct', 'Logitech Z-313', '2012-11-03 23:24:28'),
 ('64', 'ten', '3', 'StoreProduct', 'Sven SPS-820', '2012-11-03 23:24:28'),
 ('65', 'ten', '3', 'StoreProduct', 'Edifier M1385', '2012-11-03 23:24:28'),
 ('66', 'ten', '3', 'StoreProduct', 'Edifier X600', '2012-11-03 23:24:28'),
 ('67', 'ten', '3', 'StoreAttribute', 'video', '2012-11-03 23:24:36'),
 ('68', 'ten', '3', 'StoreAttribute', 'phone_platform', '2012-11-03 23:24:36'),
 ('69', 'ten', '3', 'StoreAttribute', 'screen_dimension', '2012-11-03 23:24:36'),
 ('70', 'ten', '3', 'StoreAttribute', 'phone_weight', '2012-11-03 23:24:36'),
 ('71', 'ten', '3', 'StoreAttribute', 'rms_power', '2012-11-03 23:24:36'),
 ('72', 'ten', '3', 'StoreAttribute', 'phone_display', '2012-11-03 23:24:36'),
 ('73', 'ten', '3', 'StoreAttribute', 'processor_manufacturer', '2012-11-03 23:24:36'),
 ('74', 'ten', '3', 'StoreAttribute', 'corpus_material', '2012-11-03 23:24:36'),
 ('75', 'ten', '3', 'StoreAttribute', 'phone_camera', '2012-11-03 23:24:36'),
 ('76', 'ten', '3', 'StoreAttribute', 'freq', '2012-11-03 23:24:36'),
 ('77', 'ten', '3', 'StoreAttribute', 'sound_type', '2012-11-03 23:24:36'),
 ('78', 'ten', '3', 'StoreAttribute', 'tablet_screen_size', '2012-11-03 23:24:36'),
 ('79', 'ten', '3', 'StoreAttribute', 'memmory', '2012-11-03 23:24:36'),
 ('80', 'ten', '3', 'StoreAttribute', 'monitor_diagonal', '2012-11-03 23:24:36'),
 ('81', 'ten', '3', 'StoreAttribute', 'memmory_size', '2012-11-03 23:24:36'),
 ('82', 'ten', '3', 'StoreAttribute', 'memmory_type', '2012-11-03 23:24:36'),
 ('83', 'ten', '3', 'StoreAttribute', 'monitor_dimension', '2012-11-03 23:24:36'),
 ('84', 'ten', '3', 'StoreAttribute', 'weight', '2012-11-03 23:24:36'),
 ('85', 'ten', '3', 'StoreAttribute', 'screen', '2012-11-03 23:24:36'),
 ('86', 'ten', '3', 'StoreAttribute', 'view_angle', '2012-11-03 23:24:36'),
 ('87', 'ten', '3', 'StoreCategory', 'Игровой', '2012-11-03 23:24:52'),
 ('88', 'ten', '3', 'StoreCategory', 'Бюджетный', '2012-11-03 23:24:55'),
 ('89', 'ten', '3', 'StoreCategory', 'Ноутбуки', '2012-11-03 23:24:59'),
 ('90', 'ten', '3', 'StoreCategory', 'Компьютерная акустика', '2012-11-03 23:25:02'),
 ('91', 'ten', '3', 'StoreCategory', 'Планшеты', '2012-11-03 23:25:08'),
 ('92', 'ten', '3', 'StoreCategory', 'Компьютеры', '2012-11-03 23:25:11'),
 ('93', 'ten', '3', 'StoreCategory', 'Мониторы', '2012-11-03 23:25:14'),
 ('94', 'ten', '3', 'StoreCategory', 'Телефоны', '2012-11-03 23:25:17'),
 ('95', 'ten', '1', 'StoreCategory', 'Акции', '2012-11-04 20:23:58'),
 ('96', 'ten', '1', 'StoreCategory', 'Контакты', '2012-11-04 20:24:03'),
 ('97', 'ten', '3', 'StoreCategory', 'Акции', '2012-11-04 20:24:57'),
 ('98', 'ten', '3', 'StoreCategory', 'Контакты', '2012-11-04 20:25:00'),
 ('99', 'ten', '1', 'StoreAttribute', 'color', '2012-11-07 22:30:09'),
 ('100', 'ten', '1', 'StoreAttribute', 'size', '2012-11-07 22:30:39'),
 ('101', 'ten', '3', 'StoreProductType', 'Простой продукт', '2012-11-07 22:33:55'),
 ('102', 'ten', '3', 'StoreProductType', 'Ноутбук', '2012-11-07 22:33:55'),
 ('103', 'ten', '3', 'StoreProductType', 'Акустика', '2012-11-07 22:33:55'),
 ('104', 'ten', '3', 'StoreProductType', 'Монитор', '2012-11-07 22:33:55'),
 ('105', 'ten', '3', 'StoreProductType', 'Телефон', '2012-11-07 22:33:55'),
 ('106', 'ten', '3', 'StoreProductType', 'Планшет', '2012-11-07 22:33:55'),
 ('107', 'ten', '1', 'StoreProductType', 'Носки', '2012-11-07 22:34:12'),
 ('108', 'ten', '1', 'StoreProduct', 'Носочки', '2012-11-07 22:36:02'),
 ('109', 'ten', '2', 'StoreProduct', 'Носочки', '2012-11-07 22:36:37'),
 ('110', 'ten', '2', 'StoreProduct', 'Носочки', '2012-11-07 22:36:59'),
 ('111', 'ten', '2', 'StoreProduct', 'Носочки', '2012-11-07 22:37:17'),
 ('112', 'ten', '2', 'StoreProduct', 'Носочки', '2012-11-07 22:38:27'),
 ('113', 'ten', '2', 'StoreProduct', 'Носочки', '2012-11-07 22:38:52'),
 ('114', 'ten', '2', 'StoreProduct', 'Носочки', '2012-11-07 22:39:43'),
 ('115', 'ten', '2', 'StoreProduct', 'Носочки', '2012-11-07 22:40:55'),
 ('116', 'ten', '2', 'StoreProduct', 'Носочки', '2012-11-07 22:52:20'),
 ('117', 'ten', '2', 'StoreProduct', 'Носочки', '2012-11-07 22:54:14'),
 ('118', 'ten', '2', 'StoreProduct', 'Носочки', '2012-11-07 22:54:40'),
 ('119', 'ten', '2', 'StoreProduct', 'Носочки', '2012-11-07 22:55:05'),
 ('120', 'ten', '1', 'StoreProduct', 'test', '2012-11-07 22:56:54'),
 ('121', 'ten', '3', 'StoreProduct', 'Носочки', '2012-11-07 22:57:19'),
 ('122', 'ten', '3', 'StoreProduct', 'test', '2012-11-07 22:57:19'),
 ('123', 'ten', '2', 'StoreAttribute', 'size', '2012-11-07 22:57:53'),
 ('124', 'ten', '2', 'StoreAttribute', 'color', '2012-11-07 22:58:01'),
 ('125', 'ten', '2', 'StoreAttribute', 'size', '2012-11-07 22:59:23'),
 ('126', 'ten', '2', 'StoreAttribute', 'size', '2012-11-07 23:58:42'),
 ('127', 'ten', '1', 'StoreManufacturer', 'Carters', '2012-11-07 23:59:32'),
 ('128', 'ten', '1', 'StoreProduct', 'Носочки', '2012-11-08 00:00:44'),
 ('129', 'ten', '2', 'StoreProduct', 'Носочки', '2012-11-08 00:09:05'),
 ('130', 'ten', '2', 'StoreProduct', 'Носочки', '2012-11-08 00:09:59'),
 ('131', 'ten', '2', 'StoreProduct', 'Носочки', '2012-11-08 00:15:33'),
 ('132', 'ten', '2', 'StoreProduct', 'Носочки', '2012-11-08 00:25:43'),
 ('133', 'ten', '2', 'StoreProduct', 'Носочки', '2012-11-08 00:26:10'),
 ('134', 'ten', '2', 'StoreProductType', 'Носки', '2012-11-08 00:33:22'),
 ('135', 'ten', '2', 'StoreAttribute', 'size', '2012-11-08 00:34:03'),
 ('136', 'ten', '2', 'StoreProduct', 'Носочки', '2012-11-08 00:35:37'),
 ('137', 'ten', '2', 'StoreAttribute', 'size', '2012-11-08 00:41:13'),
 ('138', 'ten', '2', 'StoreAttribute', 'size', '2012-11-08 00:41:38'),
 ('139', 'ten', '2', 'StoreAttribute', 'size', '2012-11-08 00:46:17'),
 ('140', 'ten', '2', 'StoreAttribute', 'color', '2012-11-08 00:46:29'),
 ('141', 'ten', '2', 'StoreAttribute', 'size', '2012-11-08 00:47:02'),
 ('142', 'ten', '2', 'StoreAttribute', 'color', '2012-11-08 00:47:07'),
 ('143', 'ten', '2', 'StoreProductType', 'Носки', '2012-11-08 00:47:33'),
 ('144', 'ten', '1', 'StoreProduct', 'test', '2012-11-08 00:48:59'),
 ('145', 'ten', '2', 'StoreProduct', 'test', '2012-11-08 00:55:53'),
 ('146', 'ten', '2', 'StoreProduct', 'Носочки', '2012-11-08 14:29:01'),
 ('147', 'ten', '2', 'StoreProduct', 'Носочки', '2012-11-08 23:47:32'),
 ('148', 'ten', '2', 'StoreProduct', 'Носочки', '2012-11-08 23:48:50'),
 ('149', 'ten', '2', 'StoreProduct', 'Носочки', '2012-11-09 00:08:31'),
 ('150', 'ten', '2', 'StoreProduct', 'Носочки', '2012-11-09 00:10:11'),
 ('151', 'ten', '2', 'StoreProduct', 'test', '2012-11-09 22:56:52'),
 ('152', 'ten', '2', 'StoreProduct', 'test', '2012-11-09 22:58:53'),
 ('153', 'ten', '2', 'StoreProduct', 'test', '2012-11-09 23:00:40'),
 ('154', 'ten', '2', 'StoreProduct', 'test', '2012-11-09 23:01:04'),
 ('155', 'ten', '2', 'StoreProduct', 'test', '2012-11-09 23:01:08'),
 ('156', 'ten', '2', 'StoreProduct', 'test', '2012-11-09 23:01:22'),
 ('157', 'ten', '2', 'StoreProduct', 'test', '2012-11-09 23:01:29'),
 ('158', 'ten', '2', 'StoreProduct', 'test', '2012-11-09 23:01:49'),
 ('159', 'ten', '2', 'StoreProduct', 'test', '2012-11-09 23:02:05'),
 ('160', 'ten', '2', 'StoreProduct', 'test', '2012-11-09 23:02:46'),
 ('161', 'ten', '2', 'StoreProduct', 'test', '2012-11-09 23:03:17'),
 ('162', 'ten', '2', 'StoreProduct', 'test', '2012-11-09 23:05:07'),
 ('163', 'ten', '2', 'StoreProduct', 'test', '2012-11-09 23:05:31'),
 ('164', 'ten', '2', 'StoreProduct', 'test', '2012-11-09 23:05:41'),
 ('165', 'ten', '2', 'StoreProduct', 'test', '2012-11-09 23:07:20'),
 ('166', 'ten', '2', 'StoreProduct', 'Носочки', '2012-11-09 23:48:42'),
 ('167', 'ten', '2', 'StoreProduct', 'Носочки', '2012-11-09 23:55:27'),
 ('168', 'ten', '2', 'StoreProduct', 'test', '2012-11-09 23:55:27'),
 ('169', 'ten', '2', 'StoreProduct', 'Носочки', '2012-11-09 23:55:47'),
 ('170', 'ten', '2', 'StoreProduct', 'test', '2012-11-09 23:55:47');



--
-- Structure for table `AuthAssignment`
--

DROP TABLE IF EXISTS `AuthAssignment`;
CREATE TABLE `AuthAssignment` (
  `itemname` varchar(64) NOT NULL,
  `userid` varchar(64) NOT NULL,
  `bizrule` text,
  `data` text,
  PRIMARY KEY (`itemname`,`userid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


--
-- Data for table `AuthAssignment`
--

INSERT INTO `AuthAssignment` (`itemname`, `userid`, `bizrule`, `data`) VALUES
 ('Admin', '1', NULL, NULL);



--
-- Structure for table `AuthItem`
--

DROP TABLE IF EXISTS `AuthItem`;
CREATE TABLE `AuthItem` (
  `name` varchar(64) NOT NULL,
  `type` int(11) NOT NULL,
  `description` text,
  `bizrule` text,
  `data` text,
  PRIMARY KEY (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


--
-- Data for table `AuthItem`
--

INSERT INTO `AuthItem` (`name`, `type`, `description`, `bizrule`, `data`) VALUES
 ('Admin', '2', NULL, NULL, 'N;'),
 ('Authenticated', '2', NULL, NULL, 'N;'),
 ('Guest', '2', NULL, NULL, 'N;');



--
-- Structure for table `AuthItemChild`
--

DROP TABLE IF EXISTS `AuthItemChild`;
CREATE TABLE `AuthItemChild` (
  `parent` varchar(64) NOT NULL,
  `child` varchar(64) NOT NULL,
  PRIMARY KEY (`parent`,`child`),
  KEY `child` (`child`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


--
-- Structure for table `Comments`
--

DROP TABLE IF EXISTS `Comments`;
CREATE TABLE `Comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL DEFAULT '0',
  `class_name` varchar(100) NOT NULL,
  `object_pk` int(11) NOT NULL,
  `status` tinyint(4) NOT NULL,
  `email` varchar(255) NOT NULL,
  `name` varchar(50) NOT NULL,
  `text` text NOT NULL,
  `created` datetime NOT NULL,
  `updated` datetime NOT NULL,
  `ip_address` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `class_name_index` (`class_name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


--
-- Structure for table `Discount`
--

DROP TABLE IF EXISTS `Discount`;
CREATE TABLE `Discount` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `active` tinyint(1) NOT NULL,
  `sum` varchar(10) NOT NULL,
  `start_date` datetime NOT NULL,
  `end_date` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `active` (`active`),
  KEY `start_date` (`start_date`),
  KEY `end_date` (`end_date`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;


--
-- Structure for table `DiscountCategory`
--

DROP TABLE IF EXISTS `DiscountCategory`;
CREATE TABLE `DiscountCategory` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `discount_id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `discount_id` (`discount_id`),
  KEY `category_id` (`category_id`)
) ENGINE=MyISAM AUTO_INCREMENT=75 DEFAULT CHARSET=utf8;


--
-- Structure for table `DiscountManufacturer`
--

DROP TABLE IF EXISTS `DiscountManufacturer`;
CREATE TABLE `DiscountManufacturer` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `discount_id` int(11) NOT NULL,
  `manufacturer_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `discount_id` (`discount_id`),
  KEY `manufacturer_id` (`manufacturer_id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;


--
-- Structure for table `Order`
--

DROP TABLE IF EXISTS `Order`;
CREATE TABLE `Order` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `secret_key` varchar(10) NOT NULL,
  `delivery_id` int(11) NOT NULL,
  `delivery_price` float(10,2) NOT NULL,
  `total_price` float(10,2) NOT NULL,
  `status_id` int(11) NOT NULL,
  `paid` tinyint(1) NOT NULL,
  `user_name` varchar(100) NOT NULL,
  `user_email` varchar(100) NOT NULL,
  `user_address` varchar(255) NOT NULL COMMENT 'delivery address',
  `user_phone` varchar(30) NOT NULL,
  `user_comment` varchar(500) NOT NULL,
  `ip_address` varchar(50) NOT NULL,
  `created` datetime NOT NULL,
  `updated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `secret_key` (`secret_key`),
  KEY `delivery_id` (`delivery_id`),
  KEY `status_id` (`status_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


--
-- Structure for table `OrderProduct`
--

DROP TABLE IF EXISTS `OrderProduct`;
CREATE TABLE `OrderProduct` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `configurable_id` int(11) NOT NULL,
  `name` text NOT NULL,
  `configurable_name` text NOT NULL COMMENT 'Store name of configurable product',
  `configurable_data` text NOT NULL,
  `variants` text NOT NULL,
  `quantity` smallint(6) NOT NULL,
  `sku` varchar(255) NOT NULL,
  `price` float(10,2) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `order_id` (`order_id`),
  KEY `product_id` (`product_id`),
  KEY `configurable_id` (`configurable_id`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;


--
-- Structure for table `OrderStatus`
--

DROP TABLE IF EXISTS `OrderStatus`;
CREATE TABLE `OrderStatus` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `position` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `position` (`position`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;


--
-- Data for table `OrderStatus`
--

INSERT INTO `OrderStatus` (`id`, `name`, `position`) VALUES
 ('1', 'Новый', '0'),
 ('2', 'Доставлен', '1'),
 ('3', 'Отменен', '2');



--
-- Structure for table `Page`
--

DROP TABLE IF EXISTS `Page`;
CREATE TABLE `Page` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `category_id` int(11) DEFAULT NULL,
  `url` varchar(255) NOT NULL,
  `created` datetime NOT NULL,
  `updated` datetime NOT NULL,
  `publish_date` datetime NOT NULL,
  `status` varchar(255) NOT NULL,
  `layout` varchar(2555) NOT NULL,
  `view` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `category_id` (`category_id`),
  KEY `url` (`url`),
  KEY `created` (`created`),
  KEY `updated` (`updated`),
  KEY `publish_date` (`publish_date`),
  KEY `status` (`status`)
) ENGINE=MyISAM AUTO_INCREMENT=15 DEFAULT CHARSET=utf8;


--
-- Data for table `Page`
--

INSERT INTO `Page` (`id`, `user_id`, `category_id`, `url`, `created`, `updated`, `publish_date`, `status`, `layout`, `view`) VALUES
 ('8', '1', NULL, 'help', '2012-06-10 22:35:51', '2012-07-07 11:47:09', '2012-06-10 22:35:29', 'published', '', ''),
 ('9', '1', NULL, 'how-to-create-order', '2012-06-10 22:36:50', '2012-07-07 11:45:53', '2012-06-10 22:36:27', 'published', '', ''),
 ('10', '1', NULL, 'garantiya', '2012-06-10 22:37:06', '2012-07-07 11:45:38', '2012-06-10 22:36:50', 'published', '', ''),
 ('11', '1', NULL, 'dostavka-i-oplata', '2012-06-10 22:37:18', '2012-07-07 11:41:49', '2012-06-10 22:37:07', 'published', '', ''),
 ('12', '1', '7', 'samsung-pitaetsya-izbezhat-zapreta-na-galaxy-nexus-v-shtatah-pri-pomoshi-patcha', '2012-07-07 12:08:50', '2012-07-07 12:09:33', '2012-07-07 12:06:19', 'published', '', ''),
 ('13', '1', '7', 'za-85-mesyacev-android-40-popal-na-11-ustroistv', '2012-07-07 12:19:44', '2012-07-07 12:33:48', '2012-07-07 12:14:48', 'published', '', ''),
 ('14', '1', '7', 'google-prezentoval-svoi-ochki-dopolnennoi-realnosti', '2012-07-07 12:26:11', '2012-07-07 12:26:11', '2012-07-07 12:25:48', 'published', '', '');



--
-- Structure for table `PageCategory`
--

DROP TABLE IF EXISTS `PageCategory`;
CREATE TABLE `PageCategory` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) DEFAULT NULL,
  `url` varchar(255) NOT NULL,
  `full_url` text NOT NULL,
  `layout` varchar(255) NOT NULL,
  `view` varchar(255) NOT NULL,
  `created` datetime NOT NULL,
  `updated` datetime NOT NULL,
  `page_size` smallint(6) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `parent_id` (`parent_id`),
  KEY `url` (`url`),
  KEY `created` (`created`),
  KEY `updated` (`updated`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;


--
-- Data for table `PageCategory`
--

INSERT INTO `PageCategory` (`id`, `parent_id`, `url`, `full_url`, `layout`, `view`, `created`, `updated`, `page_size`) VALUES
 ('7', NULL, 'news', 'news', '', '', '2012-07-07 12:06:03', '2012-07-07 12:06:03', NULL);



--
-- Structure for table `PageCategoryTranslate`
--

DROP TABLE IF EXISTS `PageCategoryTranslate`;
CREATE TABLE `PageCategoryTranslate` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `object_id` int(11) NOT NULL,
  `language_id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `description` text,
  `meta_title` varchar(255) DEFAULT NULL,
  `meta_description` varchar(255) DEFAULT NULL,
  `meta_keywords` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `object_id` (`object_id`),
  KEY `language_id` (`language_id`)
) ENGINE=MyISAM AUTO_INCREMENT=15 DEFAULT CHARSET=utf8;


--
-- Data for table `PageCategoryTranslate`
--

INSERT INTO `PageCategoryTranslate` (`id`, `object_id`, `language_id`, `name`, `description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES
 ('13', '7', '1', 'Новости', '', '', '', ''),
 ('14', '7', '9', 'Новости', '', '', '', '');



--
-- Structure for table `PageTranslate`
--

DROP TABLE IF EXISTS `PageTranslate`;
CREATE TABLE `PageTranslate` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `object_id` int(11) NOT NULL,
  `language_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `short_description` text,
  `full_description` text,
  `meta_title` varchar(255) DEFAULT NULL,
  `meta_keywords` varchar(255) DEFAULT NULL,
  `meta_description` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `object_id` (`object_id`),
  KEY `language_id` (`language_id`)
) ENGINE=MyISAM AUTO_INCREMENT=29 DEFAULT CHARSET=utf8;


--
-- Data for table `PageTranslate`
--

INSERT INTO `PageTranslate` (`id`, `object_id`, `language_id`, `title`, `short_description`, `full_description`, `meta_title`, `meta_keywords`, `meta_description`) VALUES
 ('22', '11', '9', 'Доставка и оплата', '', '', '', '', ''),
 ('15', '8', '1', 'Помощь', 'Давно выяснено, что при оценке дизайна и композиции читаемый текст мешает сосредоточиться. Lorem Ipsum используют потому, что тот обеспечивает более или менее стандартное заполнение шаблона, а также реальное распределение букв и пробелов в абзацах, которое не получается при простой дубликации \"Здесь ваш текст.. Здесь ваш текст.. Здесь ваш текст..\" Многие программы электронной вёрстки и редакторы HTML используют Lorem Ipsum в качестве текста по умолчанию, так что поиск по ключевым словам \"lorem ipsum\" сразу показывает, как много веб-страниц всё ещё дожидаются своего настоящего рождения. За прошедшие годы текст Lorem Ipsum получил много версий. Некоторые версии появились по ошибке, некоторые - намеренно (например, юмористические варианты).', '', '', '', ''),
 ('16', '8', '9', 'Помощь', '', '', '', '', ''),
 ('17', '9', '1', 'Как сделать заказ', '<p>Есть много вариантов Lorem Ipsum, но большинство из них имеет не всегда приемлемые модификации, например, юмористические вставки или слова, которые даже отдалённо не напоминают латынь. Если вам нужен Lorem Ipsum для серьёзного проекта, вы наверняка не хотите какой-нибудь шутки, скрытой в середине абзаца. Также все другие известные генераторы Lorem Ipsum используют один и тот же текст, который они просто повторяют, пока не достигнут нужный объём. Это делает предлагаемый здесь генератор единственным настоящим Lorem Ipsum генератором. Он использует словарь из более чем 200 латинских слов, а также набор моделей предложений. В результате сгенерированный Lorem Ipsum выглядит правдоподобно, не имеет повторяющихся абзацей или \"невозможных\" слов.</p>', '', '', '', ''),
 ('18', '9', '9', 'Как сделать заказ', '', '', '', '', ''),
 ('19', '10', '1', 'Гарантия', '<p>Многие думают, что Lorem Ipsum - взятый с потолка псевдо-латинский набор слов, но это не совсем так. Его корни уходят в один фрагмент классической латыни 45 года н.э., то есть более двух тысячелетий назад. Ричард МакКлинток, профессор латыни из колледжа Hampden-Sydney, штат Вирджиния, взял одно из самых странных слов в Lorem Ipsum, \"consectetur\", и занялся его поисками в классической латинской литературе.</p>\r\n<p>В результате он нашёл неоспоримый первоисточник Lorem Ipsum в разделах 1.10.32 и 1.10.33 книги \"de Finibus Bonorum et Malorum\" (\"О пределах добра и зла\"), написанной Цицероном в 45 году н.э. Этот трактат по теории этики был очень популярен в эпоху Возрождения. Первая строка Lorem Ipsum, \"Lorem ipsum dolor sit amet..\", происходит от одной из строк в разделе 1.10.32 Классический текст Lorem Ipsum, используемый с XVI века, приведён ниже. Также даны разделы 1.10.32 и 1.10.33 \"de Finibus Bonorum et Malorum\" Цицерона и их английский перевод, сделанный H. Rackham, 1914 год.</p>', '', '', '', ''),
 ('20', '10', '9', 'Гарантия', '', '', '', '', ''),
 ('21', '11', '1', 'Доставка и оплата', '<p>Давно выяснено, что при оценке дизайна и композиции читаемый текст мешает сосредоточиться. Lorem Ipsum используют потому, что тот обеспечивает более или менее стандартное заполнение шаблона, а также реальное распределение букв и пробелов в абзацах, которое не получается при простой дубликации \"Здесь ваш текст.. Здесь ваш текст.. Здесь ваш текст..\" Многие программы электронной вёрстки и редакторы HTML используют Lorem Ipsum в качестве текста по умолчанию, так что поиск по ключевым словам \"lorem ipsum\" сразу показывает, как много веб-страниц всё ещё дожидаются своего настоящего рождения. За прошедшие годы текст Lorem Ipsum получил много версий. Некоторые версии появились по ошибке, некоторые - намеренно (например, юмористические варианты).</p>', '', '', '', ''),
 ('23', '12', '1', 'Samsung пытается избежать запрета на Galaxy Nexus', 'Текущую ситуацию с судебным противостоянием Apple и Samsung в Штатах (ссылка по теме) можно описать строчкой их двух слов: всё плохо. ', 'В смысле всё плохо для Samsung — южнокорейская корпорация так и не сумела отбиться от назначенного судом предварительного запрета на американские продажи планшетников Galaxy Tab 10.1 и, главное, новейших смартфонов Galaxy Nexus. Расклад намечается хуже некуда: по некоторым выкладкам, потенциальный ущерб от подобного запрета может достигнуть 180 млн. долларов, две трети из которых придутся на непроданные Galaxy Nexus.', '', '', ''),
 ('25', '13', '1', 'За 8,5 месяцев Android 4.0 попал на 11% устройств', 'В свое время платформа Android 2.x распространялась активнее, чем Android 4.0 Ice Cream Sandwich, а ведь уже появилась новая мобильная ОС от Google — Android 4.1 Jelly Bean. За 8,5 месяцев своего существования Android ICS попал на 10,9% устройств, а лидировать на рынке продолжает Android 2,3 Gingerbread.', '', '', '', ''),
 ('24', '12', '9', 'Samsung пытается избежать запрета на Galaxy Nexus в Штатах при помощи патча', 'Текущую ситуацию с судебным противостоянием Apple и Samsung в Штатах (ссылка по теме) можно описать строчкой их двух слов: всё плохо. В смысле всё плохо для Samsung — южнокорейская корпорация так и не сумела отбиться от назначенного судом предварительного запрета на американские продажи планшетников Galaxy Tab 10.1 и, главное, новейших смартфонов Galaxy Nexus. Расклад намечается хуже некуда: по некоторым выкладкам, потенциальный ущерб от подобного запрета может достигнуть 180 млн. долларов, две трети из которых придутся на непроданные Galaxy Nexus.', '', '', '', ''),
 ('26', '13', '9', 'За 8,5 месяцев Android 4.0 попал на 11% устройств', 'В свое время платформа Android 2.x распространялась активнее, чем Android 4.0 Ice Cream Sandwich, а ведь уже появилась новая мобильная ОС от Google — Android 4.1 Jelly Bean. За 8,5 месяцев своего существования Android ICS попал на 10,9% устройств, а лидировать на рынке продолжает Android 2,3 Gingerbread.', '', '', '', ''),
 ('27', '14', '1', 'Google презентовал свои очки дополненной реальности‎', 'Компания Google приступит к продаже очков дополненной реальности, который разрабатываются в рамках проекта Google Project Glass, пишет блог All Things Digital. ', 'Очки будут стоить 1,5 тысячи долларов, и поставки стартуют в начале 2013 года. Устройство, однако, будет предназначено только для разработчиков. Оформить предварительный заказ на него смогут исключительно посетители конференции I/O, открывшейся 27 июня в Сан-Франциско. ', '', '', ''),
 ('28', '14', '9', 'Google презентовал свои очки дополненной реальности‎', 'Компания Google приступит к продаже очков дополненной реальности, который разрабатываются в рамках проекта Google Project Glass, пишет блог All Things Digital. ', 'Очки будут стоить 1,5 тысячи долларов, и поставки стартуют в начале 2013 года. Устройство, однако, будет предназначено только для разработчиков. Оформить предварительный заказ на него смогут исключительно посетители конференции I/O, открывшейся 27 июня в Сан-Франциско. ', '', '', '');



--
-- Structure for table `Rights`
--

DROP TABLE IF EXISTS `Rights`;
CREATE TABLE `Rights` (
  `itemname` varchar(64) NOT NULL,
  `type` int(11) NOT NULL,
  `weight` int(11) NOT NULL,
  PRIMARY KEY (`itemname`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


--
-- Structure for table `StoreAttribute`
--

DROP TABLE IF EXISTS `StoreAttribute`;
CREATE TABLE `StoreAttribute` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `type` tinyint(4) NOT NULL,
  `display_on_front` tinyint(1) NOT NULL DEFAULT '1',
  `use_in_filter` tinyint(1) NOT NULL,
  `use_in_variants` tinyint(1) NOT NULL,
  `use_in_compare` tinyint(1) NOT NULL DEFAULT '0',
  `select_many` tinyint(1) NOT NULL,
  `position` int(11) DEFAULT '0',
  `required` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `use_in_filter` (`use_in_filter`),
  KEY `display_on_front` (`display_on_front`),
  KEY `position` (`position`),
  KEY `use_in_variants` (`use_in_variants`),
  KEY `use_in_compare` (`use_in_compare`),
  KEY `name` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=23 DEFAULT CHARSET=utf8;


--
-- Data for table `StoreAttribute`
--

INSERT INTO `StoreAttribute` (`id`, `name`, `type`, `display_on_front`, `use_in_filter`, `use_in_variants`, `use_in_compare`, `select_many`, `position`, `required`) VALUES
 ('21', 'color', '3', '0', '1', '0', '1', '1', '2', '0'),
 ('22', 'size', '3', '1', '1', '1', '1', '1', '1', '0');



--
-- Structure for table `StoreAttributeOption`
--

DROP TABLE IF EXISTS `StoreAttributeOption`;
CREATE TABLE `StoreAttributeOption` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `attribute_id` int(11) NOT NULL,
  `position` tinyint(4) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `attribute_id` (`attribute_id`),
  KEY `position` (`position`)
) ENGINE=MyISAM AUTO_INCREMENT=123 DEFAULT CHARSET=utf8;


--
-- Data for table `StoreAttributeOption`
--

INSERT INTO `StoreAttributeOption` (`id`, `attribute_id`, `position`) VALUES
 ('122', '21', '1'),
 ('121', '21', '0'),
 ('120', '22', '1'),
 ('119', '22', '0');



--
-- Structure for table `StoreAttributeOptionTranslate`
--

DROP TABLE IF EXISTS `StoreAttributeOptionTranslate`;
CREATE TABLE `StoreAttributeOptionTranslate` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `language_id` int(11) NOT NULL,
  `object_id` int(11) NOT NULL,
  `value` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `language_id` (`language_id`),
  KEY `object_id` (`object_id`)
) ENGINE=MyISAM AUTO_INCREMENT=245 DEFAULT CHARSET=utf8;


--
-- Data for table `StoreAttributeOptionTranslate`
--

INSERT INTO `StoreAttributeOptionTranslate` (`id`, `language_id`, `object_id`, `value`) VALUES
 ('241', '1', '121', 'Белый'),
 ('242', '9', '121', ''),
 ('243', '1', '122', 'Черный'),
 ('244', '9', '122', ''),
 ('240', '9', '120', ''),
 ('239', '1', '120', '5M'),
 ('238', '9', '119', ''),
 ('237', '1', '119', '3M');



--
-- Structure for table `StoreAttributeTranslate`
--

DROP TABLE IF EXISTS `StoreAttributeTranslate`;
CREATE TABLE `StoreAttributeTranslate` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `object_id` int(11) NOT NULL,
  `language_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `object_id` (`object_id`),
  KEY `language_id` (`language_id`)
) ENGINE=MyISAM AUTO_INCREMENT=63 DEFAULT CHARSET=utf8;


--
-- Data for table `StoreAttributeTranslate`
--

INSERT INTO `StoreAttributeTranslate` (`id`, `object_id`, `language_id`, `title`) VALUES
 ('60', '21', '9', 'Цвет'),
 ('61', '22', '1', 'Размер'),
 ('59', '21', '1', 'Цвет'),
 ('62', '22', '9', 'Размер');



--
-- Structure for table `StoreCategory`
--

DROP TABLE IF EXISTS `StoreCategory`;
CREATE TABLE `StoreCategory` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `lft` int(10) unsigned NOT NULL,
  `rgt` int(10) unsigned NOT NULL,
  `level` smallint(5) unsigned NOT NULL,
  `url` varchar(255) NOT NULL,
  `full_path` varchar(255) NOT NULL,
  `layout` varchar(255) NOT NULL,
  `view` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `lft` (`lft`),
  KEY `rgt` (`rgt`),
  KEY `level` (`level`),
  KEY `url` (`url`),
  KEY `full_path` (`full_path`)
) ENGINE=MyISAM AUTO_INCREMENT=232 DEFAULT CHARSET=utf8;


--
-- Data for table `StoreCategory`
--

INSERT INTO `StoreCategory` (`id`, `lft`, `rgt`, `level`, `url`, `full_path`, `layout`, `view`) VALUES
 ('1', '1', '14', '1', 'root', '', '', ''),
 ('228', '10', '11', '2', 'odezhda-dlya-malchikov', 'odezhda-dlya-malchikov', '', ''),
 ('229', '12', '13', '2', 'odezhda-dlya-devochek', 'odezhda-dlya-devochek', '', '');



--
-- Structure for table `StoreCategoryTranslate`
--

DROP TABLE IF EXISTS `StoreCategoryTranslate`;
CREATE TABLE `StoreCategoryTranslate` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `object_id` int(11) NOT NULL,
  `language_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `meta_title` varchar(255) NOT NULL,
  `meta_keywords` varchar(255) NOT NULL,
  `meta_description` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `object_id` (`object_id`),
  KEY `language_id` (`language_id`),
  KEY `name` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=48 DEFAULT CHARSET=utf8;


--
-- Data for table `StoreCategoryTranslate`
--

INSERT INTO `StoreCategoryTranslate` (`id`, `object_id`, `language_id`, `name`, `meta_title`, `meta_keywords`, `meta_description`) VALUES
 ('1', '1', '1', 'root', '', '', ''),
 ('40', '228', '1', 'Одежда для мальчиков', '', '', ''),
 ('41', '228', '9', 'Одежда для мальчиков', '', '', ''),
 ('42', '229', '1', 'Одежда для девочек', '', '', ''),
 ('43', '229', '9', 'Одежда для девочек', '', '', '');



--
-- Structure for table `StoreCurrency`
--

DROP TABLE IF EXISTS `StoreCurrency`;
CREATE TABLE `StoreCurrency` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `iso` varchar(10) NOT NULL,
  `symbol` varchar(10) NOT NULL,
  `rate` float(10,3) NOT NULL,
  `main` tinyint(1) DEFAULT NULL,
  `default` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;


--
-- Data for table `StoreCurrency`
--

INSERT INTO `StoreCurrency` (`id`, `name`, `iso`, `symbol`, `rate`, `main`, `default`) VALUES
 ('1', 'Доллары', 'USD', '$', '1.000', '0', '0'),
 ('2', 'Гривна', 'UAH', 'грн.', '8.195', '1', '1');



--
-- Structure for table `StoreDeliveryMethod`
--

DROP TABLE IF EXISTS `StoreDeliveryMethod`;
CREATE TABLE `StoreDeliveryMethod` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `price` float(10,2) NOT NULL DEFAULT '0.00',
  `free_from` float(10,2) NOT NULL DEFAULT '0.00',
  `position` smallint(6) NOT NULL,
  `active` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `position` (`position`)
) ENGINE=MyISAM AUTO_INCREMENT=17 DEFAULT CHARSET=utf8;


--
-- Data for table `StoreDeliveryMethod`
--

INSERT INTO `StoreDeliveryMethod` (`id`, `price`, `free_from`, `position`, `active`) VALUES
 ('14', '10.00', '0.00', '0', '1'),
 ('15', '0.00', '0.00', '1', '1'),
 ('16', '30.00', '0.00', '2', '1');



--
-- Structure for table `StoreDeliveryMethodTranslate`
--

DROP TABLE IF EXISTS `StoreDeliveryMethodTranslate`;
CREATE TABLE `StoreDeliveryMethodTranslate` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `object_id` int(11) NOT NULL,
  `language_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` text,
  PRIMARY KEY (`id`),
  KEY `object_id` (`object_id`),
  KEY `language_id` (`language_id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;


--
-- Data for table `StoreDeliveryMethodTranslate`
--

INSERT INTO `StoreDeliveryMethodTranslate` (`id`, `object_id`, `language_id`, `name`, `description`) VALUES
 ('1', '14', '1', 'Курьером', ''),
 ('2', '14', '9', 'English', 'english description'),
 ('3', '15', '1', 'Самовывоз', ''),
 ('4', '15', '9', 'Самовывоз', ''),
 ('5', '16', '1', 'Адресная доставка по стране', ''),
 ('6', '16', '9', 'Адресная доставка по стране', '');



--
-- Structure for table `StoreDeliveryPayment`
--

DROP TABLE IF EXISTS `StoreDeliveryPayment`;
CREATE TABLE `StoreDeliveryPayment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `delivery_id` int(11) NOT NULL,
  `payment_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=59 DEFAULT CHARSET=utf8 COMMENT='Saves relations between delivery and payment methods ';


--
-- Data for table `StoreDeliveryPayment`
--

INSERT INTO `StoreDeliveryPayment` (`id`, `delivery_id`, `payment_id`) VALUES
 ('24', '12', '14'),
 ('23', '10', '16'),
 ('22', '10', '13'),
 ('21', '10', '14'),
 ('34', '11', '16'),
 ('33', '11', '13'),
 ('25', '12', '15'),
 ('26', '12', '16'),
 ('51', '14', '20'),
 ('50', '14', '18'),
 ('49', '14', '17'),
 ('52', '14', '19'),
 ('53', '15', '18'),
 ('54', '15', '20'),
 ('55', '16', '17'),
 ('56', '16', '18'),
 ('57', '16', '20'),
 ('58', '16', '19');



--
-- Structure for table `StoreManufacturer`
--

DROP TABLE IF EXISTS `StoreManufacturer`;
CREATE TABLE `StoreManufacturer` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `url` varchar(255) NOT NULL,
  `layout` varchar(255) NOT NULL,
  `view` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `url` (`url`)
) ENGINE=MyISAM AUTO_INCREMENT=20 DEFAULT CHARSET=utf8;


--
-- Data for table `StoreManufacturer`
--

INSERT INTO `StoreManufacturer` (`id`, `url`, `layout`, `view`) VALUES
 ('19', 'carters', '', '');



--
-- Structure for table `StoreManufacturerTranslate`
--

DROP TABLE IF EXISTS `StoreManufacturerTranslate`;
CREATE TABLE `StoreManufacturerTranslate` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `object_id` int(11) NOT NULL,
  `language_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `meta_title` varchar(255) NOT NULL,
  `meta_keywords` varchar(255) NOT NULL,
  `meta_description` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `object_id` (`object_id`),
  KEY `language_id` (`language_id`)
) ENGINE=MyISAM AUTO_INCREMENT=55 DEFAULT CHARSET=utf8;


--
-- Data for table `StoreManufacturerTranslate`
--

INSERT INTO `StoreManufacturerTranslate` (`id`, `object_id`, `language_id`, `name`, `description`, `meta_title`, `meta_keywords`, `meta_description`) VALUES
 ('54', '19', '9', 'Carters', '', '', '', ''),
 ('53', '19', '1', 'Carters', '', '', '', '');



--
-- Structure for table `StorePaymentMethod`
--

DROP TABLE IF EXISTS `StorePaymentMethod`;
CREATE TABLE `StorePaymentMethod` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `currency_id` int(11) NOT NULL,
  `active` tinyint(1) DEFAULT NULL,
  `payment_system` varchar(100) NOT NULL,
  `position` smallint(6) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `currency_id` (`currency_id`)
) ENGINE=MyISAM AUTO_INCREMENT=21 DEFAULT CHARSET=utf8;


--
-- Data for table `StorePaymentMethod`
--

INSERT INTO `StorePaymentMethod` (`id`, `currency_id`, `active`, `payment_system`, `position`) VALUES
 ('17', '1', '1', 'webmoney', '0'),
 ('18', '2', '1', '', '2'),
 ('19', '1', '1', 'robokassa', '1'),
 ('20', '2', '1', '', '3');



--
-- Structure for table `StorePaymentMethodTranslate`
--

DROP TABLE IF EXISTS `StorePaymentMethodTranslate`;
CREATE TABLE `StorePaymentMethodTranslate` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `object_id` int(11) NOT NULL,
  `language_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` text,
  PRIMARY KEY (`id`),
  KEY `object_id` (`object_id`),
  KEY `language_id` (`language_id`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;


--
-- Data for table `StorePaymentMethodTranslate`
--

INSERT INTO `StorePaymentMethodTranslate` (`id`, `object_id`, `language_id`, `name`, `description`) VALUES
 ('1', '17', '1', 'WebMoney', 'WebMoney — это универсальное средство для расчетов в Сети, целая среда финансовых взаимоотношений, которой сегодня пользуются миллионы людей по всему миру.'),
 ('2', '17', '9', 'English payment1', 'russian description'),
 ('3', '18', '1', 'Наличная', 'Наличная оплата осуществляется только в рублях при доставке товара курьером покупателю.'),
 ('7', '20', '1', 'Безналичная', ' Стоимость товара при безналичной оплате без ПДВ равна розничной цене товара + 2% '),
 ('8', '20', '9', 'Безналичная', ''),
 ('4', '18', '9', 'Наличка', '<p>ыла оылдао ылдао ылдоа ылдва<br />ыаол ывла оывалд ыова</p>'),
 ('5', '19', '1', 'Robokassa', 'Многими пользователями электронные платежные системы расцениваются в качестве наиболее удобного средства оплаты товаров и услуг в Интернете.'),
 ('6', '19', '9', 'Robokassa', '<p>Description goes here</p>');



--
-- Structure for table `StoreProduct`
--

DROP TABLE IF EXISTS `StoreProduct`;
CREATE TABLE `StoreProduct` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `manufacturer_id` int(11) DEFAULT NULL,
  `type_id` int(11) NOT NULL,
  `use_configurations` tinyint(1) NOT NULL DEFAULT '0',
  `url` varchar(255) NOT NULL,
  `price` float(10,2) NOT NULL,
  `max_price` float(10,2) NOT NULL DEFAULT '0.00',
  `is_active` tinyint(1) NOT NULL,
  `layout` varchar(255) DEFAULT NULL,
  `view` varchar(255) DEFAULT NULL,
  `sku` varchar(255) DEFAULT NULL,
  `quantity` int(11) DEFAULT '0',
  `availability` tinyint(2) NOT NULL DEFAULT '1',
  `auto_decrease_quantity` tinyint(2) NOT NULL DEFAULT '1',
  `views_count` int(11) NOT NULL,
  `created` datetime NOT NULL,
  `updated` datetime NOT NULL,
  `added_to_cart_count` int(11) NOT NULL,
  `votes` int(11) NOT NULL,
  `rating` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `manufacturer_id` (`manufacturer_id`),
  KEY `type_id` (`type_id`),
  KEY `price` (`price`),
  KEY `max_price` (`max_price`),
  KEY `is_active` (`is_active`),
  KEY `sku` (`sku`),
  KEY `created` (`created`),
  KEY `updated` (`updated`),
  KEY `added_to_cart_count` (`added_to_cart_count`),
  KEY `views_count` (`views_count`)
) ENGINE=MyISAM AUTO_INCREMENT=49 DEFAULT CHARSET=utf8;


--
-- Data for table `StoreProduct`
--

INSERT INTO `StoreProduct` (`id`, `manufacturer_id`, `type_id`, `use_configurations`, `url`, `price`, `max_price`, `is_active`, `layout`, `view`, `sku`, `quantity`, `availability`, `auto_decrease_quantity`, `views_count`, `created`, `updated`, `added_to_cart_count`, `votes`, `rating`) VALUES
 ('47', '19', '7', '0', 'nosochki', '30.00', '0.00', '1', '', '', '', '5', '1', '1', '4', '2012-11-09 23:55:47', '2012-11-09 23:55:47', '3', '0', '0'),
 ('48', '19', '7', '1', 'test', '0.00', '0.00', '1', '', '', '', '5', '1', '1', '2', '2012-11-09 23:55:47', '2012-11-09 23:55:47', '0', '0', '0');



--
-- Structure for table `StoreProductAttributeEAV`
--

DROP TABLE IF EXISTS `StoreProductAttributeEAV`;
CREATE TABLE `StoreProductAttributeEAV` (
  `entity` int(11) unsigned NOT NULL,
  `attribute` varchar(250) NOT NULL,
  `value` text NOT NULL,
  KEY `ikEntity` (`entity`),
  KEY `attribute` (`attribute`),
  KEY `value` (`value`(50))
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


--
-- Data for table `StoreProductAttributeEAV`
--

INSERT INTO `StoreProductAttributeEAV` (`entity`, `attribute`, `value`) VALUES
 ('48', 'size', '119');



--
-- Structure for table `StoreProductCategoryRef`
--

DROP TABLE IF EXISTS `StoreProductCategoryRef`;
CREATE TABLE `StoreProductCategoryRef` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product` int(11) NOT NULL,
  `category` int(11) NOT NULL,
  `is_main` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `category` (`category`),
  KEY `product` (`product`),
  KEY `is_main` (`is_main`)
) ENGINE=MyISAM AUTO_INCREMENT=107 DEFAULT CHARSET=utf8;


--
-- Data for table `StoreProductCategoryRef`
--

INSERT INTO `StoreProductCategoryRef` (`id`, `product`, `category`, `is_main`) VALUES
 ('106', '48', '1', '1'),
 ('103', '47', '229', '0'),
 ('102', '47', '228', '0'),
 ('105', '48', '228', '0'),
 ('104', '47', '1', '1');



--
-- Structure for table `StoreProductConfigurableAttributes`
--

DROP TABLE IF EXISTS `StoreProductConfigurableAttributes`;
CREATE TABLE `StoreProductConfigurableAttributes` (
  `product_id` int(11) NOT NULL COMMENT 'Attributes available to configure product',
  `attribute_id` int(11) NOT NULL,
  UNIQUE KEY `product_attribute_index` (`product_id`,`attribute_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


--
-- Data for table `StoreProductConfigurableAttributes`
--

INSERT INTO `StoreProductConfigurableAttributes` (`product_id`, `attribute_id`) VALUES
 ('48', '22');



--
-- Structure for table `StoreProductConfigurations`
--

DROP TABLE IF EXISTS `StoreProductConfigurations`;
CREATE TABLE `StoreProductConfigurations` (
  `product_id` int(11) NOT NULL COMMENT 'Saves relations beetwen product and configurations',
  `configurable_id` int(11) NOT NULL,
  UNIQUE KEY `idsunique` (`product_id`,`configurable_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


--
-- Structure for table `StoreProductImage`
--

DROP TABLE IF EXISTS `StoreProductImage`;
CREATE TABLE `StoreProductImage` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `is_main` tinyint(1) DEFAULT '0',
  `uploaded_by` int(11) NOT NULL,
  `date_uploaded` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=60 DEFAULT CHARSET=utf8;


--
-- Data for table `StoreProductImage`
--

INSERT INTO `StoreProductImage` (`id`, `product_id`, `name`, `is_main`, `uploaded_by`, `date_uploaded`) VALUES
 ('58', '48', '48.jpg', '1', '1', '2012-11-09 23:07:20'),
 ('59', '47', '47.jpg', '1', '1', '2012-11-09 23:48:42');



--
-- Structure for table `StoreProductTranslate`
--

DROP TABLE IF EXISTS `StoreProductTranslate`;
CREATE TABLE `StoreProductTranslate` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `object_id` int(11) NOT NULL,
  `language_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `short_description` text,
  `full_description` text,
  `meta_title` varchar(255) DEFAULT NULL,
  `meta_keywords` varchar(255) DEFAULT NULL,
  `meta_description` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `object_id` (`object_id`),
  KEY `language_id` (`language_id`)
) ENGINE=MyISAM AUTO_INCREMENT=125 DEFAULT CHARSET=utf8;


--
-- Data for table `StoreProductTranslate`
--

INSERT INTO `StoreProductTranslate` (`id`, `object_id`, `language_id`, `name`, `short_description`, `full_description`, `meta_title`, `meta_keywords`, `meta_description`) VALUES
 ('121', '47', '1', 'Носочки', '', '', '', '', ''),
 ('122', '47', '9', 'Носочки', '', '', '', '', ''),
 ('123', '48', '1', 'test', '', '', '', '', ''),
 ('124', '48', '9', 'test', '', '', '', '', '');



--
-- Structure for table `StoreProductType`
--

DROP TABLE IF EXISTS `StoreProductType`;
CREATE TABLE `StoreProductType` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `categories_preset` text NOT NULL,
  `main_category` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;


--
-- Data for table `StoreProductType`
--

INSERT INTO `StoreProductType` (`id`, `name`, `categories_preset`, `main_category`) VALUES
 ('7', 'Носки', 'a:1:{i:0;s:3:\"228\";}', '0');



--
-- Structure for table `StoreProductVariant`
--

DROP TABLE IF EXISTS `StoreProductVariant`;
CREATE TABLE `StoreProductVariant` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `attribute_id` int(11) NOT NULL,
  `option_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `price` float(10,2) NOT NULL DEFAULT '0.00',
  `price_type` tinyint(1) NOT NULL,
  `sku` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `attribute_id` (`attribute_id`),
  KEY `option_id` (`option_id`),
  KEY `product_id` (`product_id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;


--
-- Structure for table `StoreRelatedProduct`
--

DROP TABLE IF EXISTS `StoreRelatedProduct`;
CREATE TABLE `StoreRelatedProduct` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `related_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `product_id` (`product_id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COMMENT='Handle related products';


--
-- Structure for table `StoreTypeAttribute`
--

DROP TABLE IF EXISTS `StoreTypeAttribute`;
CREATE TABLE `StoreTypeAttribute` (
  `type_id` int(11) NOT NULL,
  `attribute_id` int(11) NOT NULL,
  PRIMARY KEY (`type_id`,`attribute_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


--
-- Data for table `StoreTypeAttribute`
--

INSERT INTO `StoreTypeAttribute` (`type_id`, `attribute_id`) VALUES
 ('7', '21'),
 ('7', '22');



--
-- Structure for table `StoreWishlist`
--

DROP TABLE IF EXISTS `StoreWishlist`;
CREATE TABLE `StoreWishlist` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `key` varchar(10) NOT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `key` (`key`),
  KEY `user_id` (`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;


--
-- Data for table `StoreWishlist`
--

INSERT INTO `StoreWishlist` (`id`, `key`, `user_id`) VALUES
 ('1', '1qc1z9uiy3', '1');



--
-- Structure for table `StoreWishlistProducts`
--

DROP TABLE IF EXISTS `StoreWishlistProducts`;
CREATE TABLE `StoreWishlistProducts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `wishlist_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `wishlist_id` (`wishlist_id`),
  KEY `product_id` (`product_id`),
  KEY `user_id` (`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;


--
-- Structure for table `SystemLanguage`
--

DROP TABLE IF EXISTS `SystemLanguage`;
CREATE TABLE `SystemLanguage` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `code` varchar(25) NOT NULL,
  `locale` varchar(100) NOT NULL,
  `default` tinyint(1) NOT NULL,
  `flag_name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `code` (`code`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;


--
-- Data for table `SystemLanguage`
--

INSERT INTO `SystemLanguage` (`id`, `name`, `code`, `locale`, `default`, `flag_name`) VALUES
 ('1', 'Русский', 'ru', 'ru', '1', 'ru.png'),
 ('9', 'English', 'en', 'en', '0', 'us.png');



--
-- Structure for table `SystemModules`
--

DROP TABLE IF EXISTS `SystemModules`;
CREATE TABLE `SystemModules` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `enabled` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=54 DEFAULT CHARSET=utf8;


--
-- Data for table `SystemModules`
--

INSERT INTO `SystemModules` (`id`, `name`, `enabled`) VALUES
 ('7', 'users', '1'),
 ('9', 'pages', '1'),
 ('11', 'core', '1'),
 ('12', 'rights', '1'),
 ('16', 'orders', '1'),
 ('15', 'store', '1'),
 ('17', 'comments', '1'),
 ('37', 'feedback', '1'),
 ('38', 'discounts', '1'),
 ('39', 'newsletter', '1'),
 ('40', 'csv', '1'),
 ('41', 'logger', '1'),
 ('52', 'accounting1c', '1'),
 ('53', 'yandexMarket', '1');



--
-- Structure for table `SystemSettings`
--

DROP TABLE IF EXISTS `SystemSettings`;
CREATE TABLE `SystemSettings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category` varchar(255) NOT NULL,
  `key` varchar(255) NOT NULL,
  `value` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `category` (`category`),
  KEY `key` (`key`)
) ENGINE=MyISAM AUTO_INCREMENT=32 DEFAULT CHARSET=utf8;


--
-- Data for table `SystemSettings`
--

INSERT INTO `SystemSettings` (`id`, `category`, `key`, `value`) VALUES
 ('9', 'feedback', 'max_message_length', '1000'),
 ('8', 'feedback', 'enable_captcha', '1'),
 ('7', 'feedback', 'admin_email', 'admin@localhost.local'),
 ('10', '17_WebMoneyPaymentSystem', 'LMI_PAYEE_PURSE', 'Z1234565788'),
 ('11', '17_WebMoneyPaymentSystem', 'LMI_SECRET_KEY', 'theSercretPassword'),
 ('12', '18_WebMoneyPaymentSystem', 'LMI_PAYEE_PURSE', '1'),
 ('13', '18_WebMoneyPaymentSystem', 'LMI_SECRET_KEY', '2'),
 ('14', '19_RobokassaPaymentSystem', 'login', 'login'),
 ('15', '19_RobokassaPaymentSystem', 'password1', 'password1value'),
 ('16', '19_RobokassaPaymentSystem', 'password2', 'password2value'),
 ('22', 'accounting1c', 'password', 'f880fefe2aff8130bb31d480f08e47c03e655b60'),
 ('21', 'accounting1c', 'ip', '127.0.0.1'),
 ('23', 'accounting1c', 'tempdir', 'application.runtime'),
 ('24', 'yandexMarket', 'name', 'ikiddy'),
 ('25', 'yandexMarket', 'company', 'ikiddy'),
 ('26', 'yandexMarket', 'url', 'http://i-kiddy.org.ua/'),
 ('27', 'yandexMarket', 'currency_id', '2'),
 ('28', 'core', 'siteName', 'ikiddy'),
 ('29', 'core', 'productsPerPage', '10,15,25,50'),
 ('30', 'core', 'productsPerPageAdmin', '30'),
 ('31', 'core', 'theme', 'default');



--
-- Structure for table `accounting1c`
--

DROP TABLE IF EXISTS `accounting1c`;
CREATE TABLE `accounting1c` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `object_id` int(11) DEFAULT NULL,
  `object_type` int(11) DEFAULT NULL,
  `external_id` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `object_type` (`object_type`),
  KEY `external_id` (`external_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


--
-- Structure for table `grid_view_filter`
--

DROP TABLE IF EXISTS `grid_view_filter`;
CREATE TABLE `grid_view_filter` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `grid_id` varchar(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `data` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


--
-- Structure for table `user`
--

DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `created_at` datetime NOT NULL,
  `last_login` datetime NOT NULL,
  `login_ip` varchar(255) NOT NULL,
  `recovery_key` varchar(20) NOT NULL,
  `recovery_password` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=56 DEFAULT CHARSET=utf8 COMMENT='Saves user accounts';


--
-- Data for table `user`
--

INSERT INTO `user` (`id`, `username`, `password`, `email`, `created_at`, `last_login`, `login_ip`, `recovery_key`, `recovery_password`) VALUES
 ('1', 'ten', '441d249dd5f931c63a8d514ee9635a5145328c0f', 'ikiddy2012@gmail.com', '2012-11-03 14:02:25', '2012-11-09 22:55:52', '31.43.103.204', 'PXKMUEHFNK', '01A2QOPJE1KIYRP');



--
-- Structure for table `user_profile`
--

DROP TABLE IF EXISTS `user_profile`;
CREATE TABLE `user_profile` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `full_name` varchar(255) NOT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `delivery_address` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;


--
-- Data for table `user_profile`
--

INSERT INTO `user_profile` (`id`, `user_id`, `full_name`, `phone`, `delivery_address`) VALUES
 ('1', '1', 'Administrator', '000-000-00-00', 'where to delivery');


